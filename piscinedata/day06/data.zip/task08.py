import pandas as pd

def get_monthly_activity(df, department: str | None = None,
                         mutation_type: str | None = None):

    data = df.copy()
    data["Date de la mutation"] = pd.to_datetime(data["Date de la mutation"], errors="coerce")
    data = data[data["Date de la mutation"].notna()]
    data["year"] = data["Date de la mutation"].dt.year
    data["month"] = data["Date de la mutation"].dt.month

    if department is not None:
        data = data[data["Code INSEE du département"] == department]
    if mutation_type is not None:
        data = data[data["Type de mutation"] == mutation_type]

    grouped = data.groupby(["year", "month"])
    results = []

    for (year, month), group in grouped:
        results.append({
            "year": int(year),
            "month": int(month),
            "transactions": int(group.shape[0]),
            "average_price": round(group["Valeur foncière"].mean(), 2),
            "total_value": round(group["Valeur foncière"].sum(), 2)
        })
    results.sort(key=lambda x: (x["year"], x["month"]))
    return results
