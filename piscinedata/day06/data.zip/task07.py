def get_price_per_sqm_stats(df, department: str | None = None,
                            property_type: str | None = None,
                            min_surface: float | None = None,
                            max_surface:float | None = None):
    data = df.copy()

    data = data[
        (data["Valeur foncière"].notna()) &
        (data["Valeur foncière"] > 0) &
        (data["Surface réelle du bâti"].notna()) &
        (data["Surface réelle du bâti"] > 0)
    ]

    data["price_per_sqm"] = data["Valeur foncière"] / data["Surface réelle du bâti"]
    if department is not None:
        data = data[data["Code INSEE du département"] == department]
    if property_type is not None:
        data = data[data["Type de local"] == property_type]
    if min_surface is not None:
        data = data[data["Surface réelle du bâti"] >= min_surface]
    if max_surface is not None:
        data = data[data["Surface réelle du bâti"] <= max_surface]

    grouped = data.groupby("Code INSEE du département")["price_per_sqm"]
    results = []

    for dept, values in grouped:
        results.append({
            "department": dept,
            "count": int(values.count()),
            "avg_price_per_sqm": float(values.mean()),
            "median_price_per_sqm": float(values.median()),
            "min_price_per_sqm": float(values.min()),
            "max_price_per_sqm": float(values.max())
        })
    return results
